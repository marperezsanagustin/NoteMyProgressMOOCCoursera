$(document).ready(function() {
  $("#country").countrySelect();

  $('#sign-up-form').submit(function(e){
    var errorMsg = "";
    var name = $('#name');
    var email = $('#email');
    var country = $("#country").countrySelect("getSelectedCountryData").iso2.toUpperCase();
    var gender = $("#gender");
    var educationLevel = $("#level-education");
    var password = $('#password');
    var passwordConfirm = $('#password-confirm');


    // Check not empty name
    if (name.val()) {
      name.closest('.form-group').removeClass('has-error');
    } else {
      name.closest('.form-group').addClass('has-error');
      errorMsg += "<p>- Name cannot be empty.";
    }

    // Check valid email
    if (validateEmail(email.val())) {
      email.closest('.form-group').removeClass('has-error');
    } else {
      email.closest('.form-group').addClass('has-error');
      errorMsg += "<p>- Please enter a valid email.</p>";
    }

    // Check password and password confirmation
    if (password.val() != passwordConfirm.val()) {
      password.closest('.form-group').addClass('has-error');
      passwordConfirm.closest('.form-group').addClass('has-error');
      errorMsg += "<p>- Password does not match the confirm password.</p>";
    } else {
      // Check password length
      if (password.val().toString().length < 6) {
        password.closest('.form-group').addClass('has-error');
        passwordConfirm.closest('.form-group').addClass('has-error');
        errorMsg += "<p>- Password must have at least 6 characters.</p>";
      } else {
        password.closest('.form-group').removeClass('has-error');
        passwordConfirm.closest('.form-group').removeClass('has-error');
      }
    }

    $('#error-message').html(errorMsg);

    // Login
    if (errorMsg) {
      $('#error-message').html(errorMsg);
    } else {
      signUp(name.val(), email.val(), country, gender.val(), educationLevel.val(), password.val(), passwordConfirm.val());
    }

    e.preventDefault();
  });

  function signUp(name, email, country, gender, educationLevel, password, passwordConfirm) {
    var req = new XMLHttpRequest();
    req.open('POST', root + '/sign_up', true);
    req.setRequestHeader("Content-type", "application/json");

    req.onreadystatechange = function (aEvt) {
      console.log(req);
      if (req.readyState == 4) {
        if(req.status == 201) {
          login(email, password);
        }
        else {
          $('#error-message').html('<p>We are having some troubles with our server, please try again later.</p>')
        }
      }
    };
    var data = JSON.stringify({"auth": {"name": name, "email": email, "country": country, "gender": gender, "level_education": educationLevel, "password": password, "password_confirmation": passwordConfirm}});
    req.send(data);
  }
});
