$(document).ready(function() {
  chrome.storage.sync.get('active_note', function (result) {
    var code = result.active_note;
    
    var token = getToken(function(saved_token){
      if(saved_token){
        var req = new XMLHttpRequest();
        req.open('POST', root + '/get_note', true);
        req.setRequestHeader("Content-type", "application/json");
        req.setRequestHeader("Authorization", "Bearer " + saved_token);

        req.onload = function() {
          response = $.parseJSON(req.response);
          title = response.title;
          html_body = response.body;

          title_node = $('#title');

          body_node = $('#note-body');
          title_node.html(title);
          body_node.html(html_body);
        };
        var data = JSON.stringify({"code":code});
        req.send(data);
      }
      else {
        console.log('Chau')
      }

    });

  });
});
