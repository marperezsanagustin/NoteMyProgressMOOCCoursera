function create_notes(notes,container){
  $.each( notes, function( i, note ) {
      var stringValue = '<tr> <td>{title}</td><td>{date}</td><td><a href="#" class="link-note" data-note-code="{code}"><span class="glyphicon glyphicon-open-file" aria-hidden="true"></span></a></td>'
      .replace(/{title}/g,note.title)
      .replace(/{date}/g,note.created_at)
      .replace(/{code}/g,note.code);

      container.append(stringValue);
   });
}

$(document).ready(function() {

  // Close button
  $('a.close-nav').click(function () {
    window.close();
  });

  // Log out button
  $('#log-out').click(function () {
    chrome.extension.sendMessage({action: "logout"});
  });

  // Log out listener
  chrome.extension.onMessage.addListener(
    function(response, sender, sendResponse) {
      if(response.action == 'logoutDone') {
        window.location.href = "login.html";
      }
    }
  );

  $(document).on("click",".link-note", function(e){
    e.preventDefault();
    code = $(this).data("noteCode");
    chrome.storage.sync.remove('active_note', function() {});
    chrome.storage.sync.set({'active_note': code}, function(){
      window.location.href = "note.html";
    });

  });

  var token = getToken(function(saved_token){
    if(saved_token){
      var req = new XMLHttpRequest();
      req.open('GET', root + '/notes', true);
      req.setRequestHeader("Content-type", "application/json");
      req.setRequestHeader("Authorization", "Bearer " + saved_token);

      req.onload = function() {
        response = $.parseJSON(req.response);
        notes = response.notes;

        notes_table = $('#notes-table');
        table_body = notes_table.find('tbody');
        create_notes(notes,table_body);

        $('#notes-table').DataTable({
          "lengthChange": false
        });
      };

      req.send();
    }
    else {
    }

  });

});
