chrome.extension.onMessage.addListener(
  function(request, sender, sendResponse) {
    //console.log('MESSAGE: ' + request.action);
    switch (request.action) {
      case "loadExistingTabs":
        console.log(urlHistory);
        loadExistingTabs();
        break;

      case "getEffectiveTime":
        getEffectiveTime(function(response) {
          chrome.extension.sendMessage({action: "chartDataResponse", chartData: response});
          //sendResponse(response);
        });
        break;

      case "logout":
        logout(function() {
          chrome.extension.sendMessage({action: "logoutDone"});
          //sendResponse();
        });
        break;

      case "on1sec":
        setTimeout(function() {chrome.extension.sendMessage({action: "1secElapsed"})}, 1000);
        break;

      case "getIsTrackingEnabled":
        chrome.extension.sendMessage({action: "isTrackingEnabled", isTrackingEnabled: isTrackingEnabled});
        break;

      case "setIsTrackingEnabled":
        if(request.isTrackingEnabled) {
          if(currentSessionId) {
            loadExistingTabs();
            isTracking = true;
          } else {
            isTracking = false;
          }
        } else {
          urlHistory = new Array();

          isTracking = false;
        }
        isTrackingEnabled = request.isTrackingEnabled;
        break;
    }
  }
);

chrome.tabs.onUpdated.addListener(function(tabID, changeInfo, tab) {
  if(tab.status == "complete" && changeInfo.status == "complete" && tab.url.length > 0){
    // First we check if it is an LMS site
    if(matchAnyLMS(tab.url)) {
      if((!currentSessionId || !isTracking) && isTrackingEnabled) {
        startSession();
      }
      resetSessionTimer();
    }

    if(isTracking) {
      changeCurrentURL(tabID);
      updateTabState(tabID, tab.windowId, tab.url);
    }
  }
});

chrome.tabs.onRemoved.addListener(function(tabid) {
  if(isTracking) {
    console.log("Se cerro el tab: " + tabid);
    removeTab(tabid);
  }
});

chrome.windows.onRemoved.addListener(function(windowid) {
  if(isTracking) {
    changeCurrentURL(null);
    removeTabsFromWindow(windowid);
  }
});

chrome.tabs.onActiveChanged.addListener(function(tabID) {
  if(isTracking) {
    console.log("Nuevo tab activo: " + tabID);
    changeCurrentURL(tabID);
  }
});
