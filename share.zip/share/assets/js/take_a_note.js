$(document).ready(function() {

  // Close button
  $('a.close-nav').click(function () {
    window.close();
  });

  // Log out button
  $('#log-out').click(function () {
    chrome.extension.sendMessage({action: "logout"});
  });

  // Log out listener
  chrome.extension.onMessage.addListener(
    function(response, sender, sendResponse) {
      if(response.action == 'logoutDone') {
        window.location.href = "login.html";
      }
    }
  );

  var token = getToken(function(saved_token){
    if(saved_token){
      var req = new XMLHttpRequest();
      req.open('GET', root + '/courses', true);
      req.setRequestHeader("Content-type", "application/json");
      req.setRequestHeader("Authorization", "Bearer " + saved_token);

      req.onload = function() {
        response = $.parseJSON(req.response);
        courses = response.courses;

        for(i in courses) {
          $('#course-note').append($('<option>', {
            value: courses[i].id,
            text: courses[i].full_name
          }));
        }

      };

      req.send();
    }
    else {
    }

  });



  $('#body-note').summernote({
    height: 125,
    airMode: false,
    minHeight: null,             // set minimum height of editor
    maxHeight: null,             // set maximum height of editor
    focus: true,                  // set focus to editable area after initializing summernote
    codemirror: { // codemirror options
      theme: 'readable'
    },
    toolbar: [
      ['color', ['color']],
      ['fontsize', ['style', 'fontsize']],
      ['style', ['bold', 'italic', 'underline']],
      ['font', ['superscript', 'subscript']],
      ['para', ['ul', 'ol', 'paragraph']],
      ['insert', ['link', 'table', 'hr']],
      ['misc', ['undo', 'redo']]
    ]
  });

  //$('div.note-color').remove();
  $('.note-insert [data-original-title="Picture"]').hide();
  $('.note-insert [data-original-title="Video"]').hide();

  var frm = $('#note-form');

  frm.submit(function (e) {

      e.preventDefault();
      title = frm.find('#title-note').val();
      course = frm.find('#course-note').val();
      body = $('div.panel-body');
      html_body = body.html();

      var token = getToken(function(saved_token){
        if(saved_token){
          var req = new XMLHttpRequest();
          req.open('POST', root + '/create_note', true);
          req.setRequestHeader("Content-type", "application/json");
          req.setRequestHeader("Authorization", "Bearer " + saved_token);

          req.onload = function() {
            response = $.parseJSON(req.response);
            chrome.storage.sync.remove('active_note', function() {});
            chrome.storage.sync.set({'active_note': response.code}, function() {});
            window.location.href = "note.html";
          };

          var data = JSON.stringify({"title": title, "course_id": course, "body": html_body});
          req.send(data);
        }
        else {
          console.log('Chau')
        }

      });

  });

});
