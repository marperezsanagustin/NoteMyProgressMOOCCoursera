$(document).ready(function() {
  // Close button
  $('a.close-nav').click(function () {
    window.close();
  });

  // Log out button
  $('#log-out').click(function () {
    chrome.extension.sendMessage({action: "logout"});
  });

  // Log out listener
  chrome.extension.onMessage.addListener(
    function(response, sender, sendResponse) {
      if(response.action == 'logoutDone') {
        window.location.href = "login.html";
      }
    }
  );

  // Initial state
  var changesMsg = $('#changes-message');
  changesMsg.hide();
  $('.value-container').show();
  $('.edit-container').hide();

  // Edit buttons action
  $('.attribute-edit').click(function() {
    var attrInput = $(this).closest('.attribute-value').find('.edit-container input');
    attrInput.val("");
    $('.value-container').show();
    $('.edit-container').hide();
    $(this).closest('.value-container').hide();
    $(this).closest('.attribute-value').find('.edit-container').show();
    attrInput.first().focus();
  });

  $('.attribute-cancel').click(function() {
    $('.value-container').show();
    $('.edit-container').hide();
  });

  // Save changed attribute on API
  $('.attribute-save').mousedown(function(e) {
    changesMsg.hide();

    var attrInput = $(e.target).siblings().first();
    var attrNewValue = attrInput.val();
    var attrOldValue = $(e.target).closest('.attribute-value').find('.value-container span').html();

    getToken(function(token) {
      var req = new XMLHttpRequest();
      req.open('POST', root + '/user_profile/edit', true);
      req.setRequestHeader("Content-type", "application/json");
      req.setRequestHeader("Authorization", "Bearer " + token);

      req.onreadystatechange = function (aEvt) {
        if (req.readyState == 4) {
          if(req.status == 200) {
            // Success
            response = $.parseJSON(req.response);
            $('.value-container span.user-name').html(response.name);
            $('.edit-container input.user-name')[0].placeholder = response.name;

            $('.value-container span.email').html(response.email);
            $('.edit-container input.email')[0].placeholder = response.email;

            changesMsg.removeClass('alert-danger');
            changesMsg.addClass('alert-success');
            changesMsg.html('<strong>Success!</strong> Profile was updated.');
            changesMsg.show();
            setTimeout(function() {
              changesMsg.hide()
            }, 3200);
          } else {
            // Error
            response = $.parseJSON(req.response);
            changesMsg.removeClass('alert-success');
            changesMsg.addClass('alert-danger');
            changesMsg.html('<strong>Error!</strong> ' + response.error);
            changesMsg.show();
            setTimeout(function() {
              changesMsg.hide()
            }, 3200);
          }
        }
      };

      if (attrOldValue != attrNewValue && attrNewValue.length > 0) {
        var data = null;

        if (attrInput.hasClass('user-name')) {
          data = JSON.stringify({"user_name": attrNewValue});
          req.send(data);
        } else if (attrInput.hasClass('email')) {
          data = JSON.stringify({"email": attrNewValue});
          req.send(data);
        } else if (attrInput.hasClass('old-password')) {
          var newPassword = $('.new-password').val();
          var passwordConfirm = $('.password-confirmation').val();

          if(newPassword == passwordConfirm && newPassword.length > 0 && attrNewValue > 0) {
            data = JSON.stringify({"old_password": attrNewValue, "new_password": newPassword});
            req.send(data);
          }
        }
      }

      $('.value-container').show();
      $('.edit-container').hide();
    });
  });

  // Delete account behaviour
  var deleteAccount = $('#delete-account');
  var deleteAccountEdit = $('.delete-account-edit-container');
  var passwordDeleteAccount = $('#delete-account-confirmation');
  deleteAccountEdit.hide();

  deleteAccount.click(function() {
    if (deleteAccountEdit.is(':visible') && passwordDeleteAccount.val().length > 0) {
      getToken(function(token) {
        var req = new XMLHttpRequest();
        req.open('POST', root + '/user_profile/destroy', true);
        req.setRequestHeader("Content-type", "application/json");
        req.setRequestHeader("Authorization", "Bearer " + token);

        req.onreadystatechange = function (aEvt) {
          if (req.readyState == 4) {
            if(req.status == 200) {
              // Success
              response = $.parseJSON(req.response);

              changesMsg.removeClass('alert-danger');
              changesMsg.addClass('alert-success');
              changesMsg.html('<strong>Success!</strong> User was deleted successfully.');
              changesMsg.show();
              setTimeout(function() {
                changesMsg.hide();
                chrome.extension.sendMessage({action: "logout"});
              }, 2000);
            } else {
              // Error
              response = $.parseJSON(req.response);
              changesMsg.removeClass('alert-success');
              changesMsg.addClass('alert-danger');
              changesMsg.html('<strong>Error!</strong> ' + response.error);
              changesMsg.show();
              setTimeout(function() {
                changesMsg.hide()
              }, 3200);
            }
          }
        };
        data = JSON.stringify({"password": passwordDeleteAccount.val()});
        req.send(data);
      });
    } else {
      deleteAccountEdit.show();
      passwordDeleteAccount.focus();
      deleteAccount.text('Click again to delete account');
    }

  });

  $('#delete-account-cancel').click(function() {
    deleteAccountEdit.hide();
    deleteAccount.text('Delete my NoteMyProgress Account');
  });

  // Load user data
  getToken(function(token) {
    var req = new XMLHttpRequest();
    req.open('GET', root + '/user_profile/details', true);
    req.setRequestHeader("Content-type", "application/json");
    req.setRequestHeader("Authorization", "Bearer " + token);

    req.onreadystatechange = function (aEvt) {
      if (req.readyState == 4) {
        if(req.status == 200) {
          response = $.parseJSON(req.response);
          $('.value-container span.user-name').html(response.name);
          $('.edit-container input.user-name')[0].placeholder = response.name;

          $('.value-container span.email').html(response.email);
          $('.edit-container input.email')[0].placeholder = response.email;
        }
      }
    };

    req.send();
  });

});
