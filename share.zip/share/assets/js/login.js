// Shared var and functions
function validateEmail(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}

function validate_token () {
  var token = getToken(function(saved_token){
    if(saved_token){
      var req = new XMLHttpRequest();
      req.open('GET', root + '/validate_token', true);
      req.setRequestHeader("Content-type", "application/json");
      req.setRequestHeader("Authorization", "Bearer " + saved_token);

      req.onreadystatechange = function (aEvt) {
        console.log(req.response);
        if (req.readyState == 4) {
          if(req.status == 200) {
            console.log('El token guardado es valido');
            //Chronometer starts

            window.location.href = "home.html";
          }
          else {
            $('body').children().show();
          }
        }
      };

      req.send();
    }
    else {
      $('body').children().show();
    }
  });
}

function login(email, password) {
  var req = new XMLHttpRequest();
  req.open('POST', root + '/auth_user', true);
  req.setRequestHeader("Content-type", "application/json");

  req.onreadystatechange = function (aEvt) {
    if (req.readyState == 4) {
      // Login succesful
      if(req.status == 200) {
        $('#error-message').html('');
        var token = JSON.parse(req.response).auth_token;

        saveToken(token, function () {
          //chrome.extension.sendMessage({action: "loadExistingTabs"});
          window.location.href = "home.html";
        });
      }
      // Login error
      else {
        $('#error-message').html('<p>Invalid email or password, please try again.</p>')
      }
    }
  };

  var data = JSON.stringify({"email": email, "password": password});
  req.send(data);
}


$(document).ready(function() {
  // Don't show the view until the token is validated
  $('body').children().hide();

  // Show view if token validation is taking too much time or failed
  setInterval(function(){
    $('body').children().show()
  },2000);

  // Check if stored token still valid
  validate_token();

  $('#login-form').submit(function(e){
    var errorMsg = "";
    var email = $('#email');
    var password = $('#password');

    // Check valid email
    if (validateEmail(email.val())) {
      email.closest('.form-group').removeClass('has-error');
    } else {
      email.closest('.form-group').addClass('has-error');
      errorMsg += "<p>- Please enter a valid email.</p>";
    }

    // Check password length before try to login
    if (password.val().toString().length < 6) {
      password.closest('.form-group').addClass('has-error');
      errorMsg += "<p>- Password must have at least 6 characters.</p>";
    } else {
      password.closest('.form-group').removeClass('has-error');
    }

    // Login
    if (errorMsg) {
      $('#error-message').html(errorMsg);
    } else {
      login(email.val(), password.val());
    }

    e.preventDefault();
  });

});
