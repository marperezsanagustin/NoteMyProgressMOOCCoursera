function round(number, precision) {
    var pair = (number + 'e').split('e')
    var value = Math.round(pair[0] + 'e' + (+pair[1] + precision))
    pair = (value + 'e').split('e')
    return +(pair[0] + 'e' + (+pair[1] - precision))
}

var sessionStartTime = null;

$(document).ready(function() {

  // Close button
  $('a.close-nav').click(function () {
    window.close();
  });

  // Log out button
  $('#log-out').click(function () {
    chrome.extension.sendMessage({action: "logout"});
  });

  // Init tracking toggle
  var trackingToggle = $('#tracking-toggle');
  //$('send')

  // Log out listener
  chrome.extension.onMessage.addListener(
    function(response, sender, sendResponse) {
      if(response.action == 'logoutDone') {
        window.location.href = "login.html";
      }
      else if (response.action == '1secElapsed') {
        updateSessionTime();
        chrome.extension.sendMessage({action: "on1sec"});
      }
      else if (response.action == 'isTrackingEnabled') {
        if(response.isTrackingEnabled) {
          trackingToggle.bootstrapToggle('on');
        } else {
          trackingToggle.bootstrapToggle('off');
        }

        // Set the change event here to avoid triggering on loading
        trackingToggle.change(function() {
          if(trackingToggle.prop('checked')) {
            //, '#no-data', '#effectiveness-chart'
            $('#display-session-start-time, #no-data, #effectiveness-chart').css({ 'opacity' : 1.0 });
          } else {
            $('#display-session-start-time, #no-data, #effectiveness-chart').css({ 'opacity' : 0.5 });
          }
          chrome.extension.sendMessage({action: "setIsTrackingEnabled", isTrackingEnabled: trackingToggle.prop('checked')});
        });
      }
    }
  );

  chrome.extension.sendMessage({action: "getIsTrackingEnabled"});

  $('#dashboard-web').click(function(){
    chrome.storage.sync.get(['access_token'], function(items){
      var token = items.access_token;

      if(token){
        var dashboard_url = root_web + "sing_in_by_token?token=" + token;
        chrome.tabs.create({ url: dashboard_url });
      }
    });
  });

  $('#no-data').hide();

  // Pass dateTimeStart and dateTimeFinish in miliseconds since 1 Jan 1970 (UNIX format)
  function updateSessionTime() {
    var totalTime = (Date.now() - sessionStartTime)/1000; //time in seconds
    var htmlOutput = "_";
    if(totalTime < 60) {
      htmlOutput = Number(totalTime).toFixed(0) + ' seconds';
    } else {
      totalTime = totalTime/60;
      htmlOutput = Number(totalTime).toFixed(1) + ' minutes';

      if(totalTime > 60) {
        totalTime = totalTime/60;
        htmlOutput = Number(totalTime).toFixed(1) + ' hours';
      }
      //$('span#session-min').html(Number(parseFloat(3)/60.0).toFixed(1) + ' minutes');
    }
    $('span#session-min').html(htmlOutput);
  }

  // Listener to receive chart data from background
  chrome.extension.onMessage.addListener(
    function(response, sender, sendResponse) {
      if(response.action == 'chartDataResponse') {
        if(response.chartData.session_exists) {
          if(response.chartData.effective_time + response.chartData.procrastination_time > 0) {
            $('#no-data').hide();
            $('#display-session-start-time').show();
            sessionStartTime = response.chartData.session_start;
            chrome.extension.sendMessage({action: "on1sec"});
            drawChart(response.chartData.effective_time, response.chartData.procrastination_time);
            $('#effectiveness-chart').show();
          } else {
            sessionStartTime = response.chartData.session_start;
            chrome.extension.sendMessage({action: "on1sec"});
            $('#no-data').show();

          }
        } else {
          console.log(response);
          $('#no-data').html('<p>' + response.chartData.errorMsg + '</p>');
          $('#no-data').show();
          $('#display-session-start-time').hide();
        }
      }
    }
  );

  // Build chart if there is data
  getToken(function(saved_token){
    chrome.extension.sendMessage({action: "getEffectiveTime"});
  });


  function drawChart(effective_time, procrastination_time) {
    var ctx = document.getElementById("effectiveness-chart").getContext('2d');
    var myChart = new Chart(ctx, {
      type: 'pie',
      data: {
        labels: ["Effective time", "Procrastination"],
        datasets: [{
          backgroundColor: [
            "#304FFE",
            "#FE4A49"
          ],
          data: [effective_time, procrastination_time]
        }]
      },
      options: {
        tooltips: {
          callbacks: {
            label: function(tooltipItem) {
              var dataVal = 0;
              var label = "";
              if(tooltipItem.index == 0){
                dataVal = effective_time;
                label = "Effective time";
              } else {
                dataVal = procrastination_time;
                label = "Procrastination";
              }
              var precentage = Number((parseFloat(dataVal)/(effective_time+procrastination_time)) * 100.0).toFixed(2);
              var minutes = dataVal/60.0
              if(minutes < 1) {
                return label + ": " + dataVal + " sec (" + precentage + "%)";
              } else {
                return label + ": " + (dataVal/60.0).toPrecision(2) + " min (" + precentage + "%)";
              }
            }
          }
        }
      }
    });
  }
});
