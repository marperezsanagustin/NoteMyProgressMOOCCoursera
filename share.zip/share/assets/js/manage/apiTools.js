function sendUrlToApi(visitedUrl) {
  var req = new XMLHttpRequest();
  req.open('POST', root + '/urls', true);
  req.setRequestHeader("Content-type", "application/json");
  req.setRequestHeader("Authorization", "Bearer " + visitedUrl.token);

  req.onreadystatechange = function (aEvt) {
    if (req.readyState == 4) {
      // Url saved successfully
      if(req.status == 201) {
        console.log("Enviada: " + visitedUrl.url);
        visitedUrl.informed = true;

        // Special case when close the last tab
        if(urlHistory.length == 1) {
          emptyUrlHistory();
        }
      } else if (req.status == 404) {
        console.log("No se pudo guardar en API: " + visitedUrl.url);
        visitedUrl.informed = true;

        // Special case when close the last tab
        if(urlHistory.length == 1) {
          emptyUrlHistory();
        }
      }
      // Error sending the url
      else {
        console.log("Error al enviar: " + visitedUrl.url);
      }
    }
  };
  var data = JSON.stringify({"url": visitedUrl.url, "session_id": visitedUrl.sessionId, "active_time": visitedUrl.activeTime, "start": visitedUrl.init, "finish": visitedUrl.end});
  req.send(data);
}

function emptyUrlHistory() {
  for(i = 0; i < urlHistory.length; i++) {
    var current = urlHistory[i];
    // If it was already informed we remove it from the urlHistory
    if(current.informed) {
      urlHistory.splice(i, 1);
      i -= 1;
    }
    // If the url was closed but ended with active time = 0 we remove ir from the urlHistory cause it's not usefull
    else if (current.end && current.activeTime <= 0) {
      urlHistory.splice(i, 1);
      i -= 1;
    } else if (current.sessionId == null) {
      urlHistory.splice(i, 1);
      i -= 1;
    }
    // If it wasn't informed and it have a non null end date, we try to send it
    else if (current.end && current.activeTime > 0) {
      sendUrlToApi(current);
    }
  }
}

function getEffectiveTime(callback=null) {
  var output = {
    session_exists: false,
    effective_time: 0,
    procrastination_time: 0,
    session_start: null,
    errorMsg: ""
  }

  getToken(function(token){
    if(token){
      var req = new XMLHttpRequest();
      req.open('POST', root + '/get_effective_time', true);
      req.setRequestHeader("Content-type", "application/json");
      req.setRequestHeader("Cache-Control", "no-cache");
      req.setRequestHeader("Authorization", "Bearer " + token);

      req.onreadystatechange = function (aEvt) {
        if(req.readyState == 4) {
          if(req.status == 200) {
            //console.log(req.response);
            response = $.parseJSON(req.response);
            output.session_exists = true;
            output.effective_time = response.effective_time;
            output.procrastination_time = response.procrastination_time;
            output.session_start = response.session_start;
          }
          else {
            console.log(req.response);
            output.errorMsg = "Please visit a learning management system course to start your study session.";
          }


          if(callback) {
            callback(output);
          }
        }
      };
      req.send();
    }
    else {
      output.errorMsg = "Please visit a learning management system course to start your study session.";

      if(callback) {
        callback(output);
      }
      return output;
    }
  });
}

function logout(callback = null) {
  if(currentSessionId) {
    closeSession(function() {
      cleanExtensionData(callback);
    });
  } else {
    cleanExtensionData(callback);
  }
}

function cleanExtensionData(callback = null) {
  chrome.storage.sync.clear(function() {
    urlHistory = new Array();
    currentURLActiveStartTime = null;
    currentTabID = null;
    isTracking = false;
    sessionTimer = null;
    currentSessionId = null;

    if(callback) {
      callback();
    }
  });
}
