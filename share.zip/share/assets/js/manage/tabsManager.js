// Adds active time to previous tab when active tab changes
function changeCurrentURL(newTabID) {
  if(currentTabID && currentURLActiveStartTime) {
    var urlTime = Math.floor((Date.now() - currentURLActiveStartTime)/1000);
    for(i = 0; i < urlHistory.length; i++) {
      if(urlHistory[i].tabID == currentTabID && !urlHistory[i].informed) {
        if(urlTime > 0) {
          console.log('Agregados ' + urlTime.toString() + ' segundos a tab ' + urlHistory[i].url);
          urlHistory[i].activeTime += urlTime;
        }
        break;
      }
    }
  }
  currentTabID = newTabID;
  currentURLActiveStartTime = Date.now();
}

function removeTab(tabID) {
  for(i = 0; i < urlHistory.length; i++) {
    if(urlHistory[i].tabID == tabID) {
      urlHistory[i].finish();
    }
  }
  console.info(urlHistory);
}

function updateTabState(tabID, windowID, tabURL) {
  // First we close the old url (if exists)
  var len = urlHistory.length;
  var oldUrlIndex = -1;

  for(i = 1; i < (len + 1) ; i++) {
    var visitedUrl = urlHistory[len - i];
    if(visitedUrl.tabID == tabID) {
      oldUrlIndex = len - i;
      break;
    }
  }

  // Tab's not new
  if(0 <= oldUrlIndex) {
    // Other tab changes fall here
    if(urlHistory[oldUrlIndex].url == tabURL) {
      return;
    }
    // Close the old url
    if(!urlHistory[oldUrlIndex].end) {
      urlHistory[oldUrlIndex].finish();
    }
  }

  // Save the new url
  getToken(function(token) {
    if(token) {
      var newUrl = new VisitedUrl(tabID, windowID, tabURL, token);
      urlHistory.push(newUrl);
      removeDuplicates(urlHistory);
      console.info(urlHistory);
    }
  });
}

function removeTabsFromWindow(windowID) {
  for(i = 0; i < urlHistory.length; i++) {
    if(urlHistory[i].windowID == windowID) {
      urlHistory.splice(i, 1);
      i -= 1;
    }
  }
}

function removeDuplicates(array){
  for(i = 0; i < array.length; i++) {
    var current = array[i];
    for(j = i + 1; j < array.length; j++) {
      var comparated = array[j];
      if(current.url == comparated.url && current.tabID == comparated.tabID) {
        array.splice(j, 1);
        j -= 1;
      }
    }
  }
}

function loadExistingTabs() {
  getToken(function(token) {
    if(token) {
      chrome.windows.getAll({populate:true}, function(windows){
        windows.forEach( function(window) {
          window.tabs.forEach( function(tab){
            var newUrl = new VisitedUrl(tab.id, tab.windowId, tab.url, token);
            urlHistory.push(newUrl);
          });
        });
        removeDuplicates(urlHistory);
        chrome.tabs.query({active: true, currentWindow: true}, function(arrayOfTabs) {
          currentTabID = arrayOfTabs[0].id;
        });
        currentURLActiveStartTime = Date.now();
        console.log('Se detectaron las siguientes URLs abiertas:');
        console.info(urlHistory);
      });
    }
  });
}

function matchAnyLMS(url) {
  var out = false;
  for(i = 0; i < lmsUrls.length; i++) {
    if(url.match(lmsUrls[i])) {
      out = true;
      break;
    }
  };
  return out;
}
