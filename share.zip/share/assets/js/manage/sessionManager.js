$(document).ready(function() {
  getCurrentSession();
  window.setInterval(function(){
    console.log('Pidiendo sesion');
    getCurrentSession();
  }, getSessionInterval);
});



function resetSessionTimer() {
  getToken(function(token) {
    if(token) {
      if(sessionTimer) {
        window.clearTimeout(sessionTimer);
      }

      sessionTimer = window.setTimeout(function() {
        closeSession(currentSessionId);
      }, maxInactiveTime);
    }
  });
}

function startSession() {
  if((!currentSessionId || !isTracking) && isTrackingEnabled) {
    getToken(function(token) {
      var req = new XMLHttpRequest();
      req.open('POST', root + '/sessions/start', true);
      req.setRequestHeader("Content-type", "application/json");
      req.setRequestHeader("Authorization", "Bearer " + token);

      req.onreadystatechange = function (aEvt) {
        if (req.readyState == 4) {
          // Session closed
          if(req.status == 200) {
            console.log("%c Sesion de estudio comenzada correctamente: " + Date(), 'background: #3BD545; color: #fff');
            var session = JSON.parse(req.response);
            currentSessionId = session.id;
            isTracking = true;
            urlHistory = new Array();
            loadExistingTabs();
          } else {
            //console.log("Error al comenzar la sesion de estudio: ");
          }
        }
      };
      req.send();
    });
  }
}

function getCurrentSession(callback=null) {
  // request again if more than 5 minutes
  if(Math.abs((new Date()).getTime() - lastTimeGetSessionId.getTime())/(1000*60) > 5*60) {
    getToken(function(token){
      if(token){
        var output = null;
        var req = new XMLHttpRequest();
        req.open('POST', root + '/sessions/get_current', true);
        req.setRequestHeader("Content-type", "application/json");
        req.setRequestHeader("Cache-Control", "no-cache");
        req.setRequestHeader("Authorization", "Bearer " + token);

        req.onreadystatechange = function (aEvt) {
          if(req.readyState == 4) {
            if(req.status == 200) {
              console.log(req.response);
              response = $.parseJSON(req.response);
              if(currentSessionId != response.id) {
                currentSessionId = response.id;
                isTracking = true;
                resetSessionTimer();
              }
              output = response.id;
            }
            else {
              console.log(req.response);
              if(currentSessionId != null) {
                console.log('%c Sesion de estudio cerrada por la API: ' + Date(), 'background: #EA5B56; color: #fff');
              }
              currentSessionId = null;
              isTracking = false;
              sessionTimer = null;
              console.log('No se pudo obtener la sesion');
            }

            if(callback) {
              callback(output);
            }
          }
        };
        req.send();
        lastTimeGetSessionId = new Date();
      }
    });
  } else {

    if(callback) {
      callback(currentSessionId);
    }
  }
}

function closeSession(callback = null) {
  if(currentSessionId) {
    getToken(function(token) {
      var req = new XMLHttpRequest();
      req.open('POST', root + '/sessions/close', true);
      req.setRequestHeader("Content-type", "application/json");
      req.setRequestHeader("Authorization", "Bearer " + token);

      req.onreadystatechange = function (aEvt) {
        if (req.readyState == 4) {
          // Session closed
          if(req.status == 200) {
            console.log('%c Sesion de estudio cerrada correctamente: ' + Date(), 'background: #EA5B56; color: #fff');
            console.log(req.response);
            currentSessionId = null;
            isTracking = false;
            emptyUrlHistory();
          } else {
            //console.log("Error al cerrar sesion de estudio: ");
          }

          if(callback != null) {
            callback();
          }
        }
      };
      req.send();
    });
  }
}
