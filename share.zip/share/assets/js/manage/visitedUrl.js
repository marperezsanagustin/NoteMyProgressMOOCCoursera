class VisitedUrl {
  constructor(tabID, windowID, url, token) {
    // ID of the tab in which the user access to the url
    this.tabID      = tabID;
    // ID of the window in which the user access to the url
    this.windowID   = windowID;
    // Visited url
    this.url        = url;
    // Session id
    this.sessionId  = currentSessionId;
    // Token of the current user
    this.token      = token;
    // Datetime (current) when user access to the url
    this.init       = Date();
    // Datetime when user leave the url
    this.end        = null;
    // Time being active
    this.activeTime = 0;
    // informed show if information was send to API
    this.informed   = false;
  }

  finish() {
    this.end = Date();
    // Try to send all the pending requests
    emptyUrlHistory();
  }
}
