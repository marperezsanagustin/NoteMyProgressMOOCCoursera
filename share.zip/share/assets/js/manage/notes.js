$(document).ready(function() {

  // Close button
  $('a.close-nav').click(function () {
    window.close();
  });

  // Log out button
  $('#log-out').click(function () {
    chrome.storage.sync.remove('access_token', function() {});
  });
});
