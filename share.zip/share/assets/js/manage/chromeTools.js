function saveToken(token, callback=null) {
  // Saves token on chrome storage
  chrome.storage.sync.set({'access_token': token.toString()}, function() {
    if (callback) {
      callback();
    }
  });
}

function getToken(callback=null) {
  // Get the token from chrome storage
  chrome.storage.sync.get(['access_token'], function(items) {
    if (callback) {
      callback(items.access_token);
    }
  });
}
