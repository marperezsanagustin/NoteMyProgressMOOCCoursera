// This file contains all the the variables that mantains along the app flow

// LMS sites. If you want to add an LMS to track just add it's root URL in here
var lmsUrls = [
  'https://www.coursera.org/learn/*'
];

// This array contains the info of the actual url in every open tab and the urls that haven't been sent to the API
var urlHistory = new Array();

/* This vars saves the time when the current tab started it's active period and the id of the tab
   Used to  define the active time of each url */
var currentURLActiveStartTime = null;
var currentTabID = null;

// This vars are used to track sessions
var isTrackingEnabled = true;
var isTracking = false;
var sessionTimer = null;
var currentSessionId = null;
var lastTimeGetSessionId = new Date(1800, 1, 1);
var maxInactiveTime = 45*60*1000; //in miliseconds
var getSessionInterval = 1000*60; //in miliseconds

root = "";
environment = "production";

switch (environment) {
case "development":
    root = 'http://localhost:3000/api';
    break
case "production":
    root = 'http://104.131.21.237/api';
    break
default:
    root = 'http://localhost:3000/api';
    break
}
