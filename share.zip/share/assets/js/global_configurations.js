
root = "";
root_web = ""
environment = "production";

switch (environment) {
case "development":
    root = 'http://localhost:3000/api';
    root_web = 'http://localhost:3000/';
    break
case "production":
    root_web = 'http://104.131.21.237/';
    root = 'http://104.131.21.237/api';
    break
default:
    root = 'http://localhost:3000/api';
    break
}
